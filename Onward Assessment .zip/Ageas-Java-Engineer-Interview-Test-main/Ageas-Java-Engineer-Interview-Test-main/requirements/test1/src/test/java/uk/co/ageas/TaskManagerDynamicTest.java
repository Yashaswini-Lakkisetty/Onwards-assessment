package uk.co.ageas;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class TaskManagerDynamicTest {
    private TaskManagerDynamic taskManager;

    @Before
    public void setUp() {
        taskManager = new TaskManagerDynamic();
        taskManager.addTask("Task 1");
        taskManager.addTask("Task 2");
        taskManager.addTask("Task 3");
    }

    @Test
    public void testAddTask() {
        taskManager.addTask("Task 4");
        List<Task> allTasks = taskManager.getAllTasks();
        assertEquals(4, allTasks.size());
    }

    @Test
    public void testMarkTaskAsCompleted() {
        boolean result = taskManager.markTaskAsCompleted("Task 2");
        assertTrue(result); 

        List<Task> pendingTasks = taskManager.retrievePendingTasks();
        assertEquals(2, pendingTasks.size());
    }

    @Test
    public void testMarkNonExistentTaskAsCompleted() {
        boolean result = taskManager.markTaskAsCompleted("Non-existent Task");
        assertFalse(result); 
    }

    @Test
    public void testRetrievePendingTasks() {
        taskManager.markTaskAsCompleted("Task 1");
        List<Task> pendingTasks = taskManager.retrievePendingTasks();
        assertEquals(2, pendingTasks.size());
    }

    @Test
    public void testRetrieveAllTasks() {
        List<Task> allTasks = taskManager.getAllTasks();
        assertEquals(3, allTasks.size()); 
        assertFalse(allTasks.get(0).isCompleted()); 
    }
}
