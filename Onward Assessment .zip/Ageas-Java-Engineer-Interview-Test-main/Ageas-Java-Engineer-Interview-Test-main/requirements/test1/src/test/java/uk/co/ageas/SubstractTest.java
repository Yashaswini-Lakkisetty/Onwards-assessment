package uk.co.ageas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class SubstractTest {

    private Substract substract;

    @Before
    public void setUp() {
        substract = new Substract();
    }

    @Test
    public void testSubtractionWithPositiveNumbers() {
        assertEquals(4, substract.sub(6, 2)); 
    }

    @Test
    public void testSubtractionWithNegativeNumbers() {
        assertEquals(-4, substract.sub(-2, 2));
        assertEquals(0, substract.sub(-2, -2));
    }

    @Test
    public void testSubtractionWithZero() {
        assertEquals(5, substract.sub(5, 0));
        assertEquals(-5, substract.sub(0, 5));
        assertEquals(0, substract.sub(0, 0));
    }

    @Test
    public void testSubtractionWithLargeNumbers() {
        assertEquals(2000000, substract.sub(3000000, 1000000));
    }

    @Test
    public void testSubtractionWithMixedSigns() {
        assertEquals(-1, substract.sub(2, 3));
        assertEquals(1, substract.sub(3, 2));
        assertEquals(3, substract.sub(-1, -4));
    }
}
