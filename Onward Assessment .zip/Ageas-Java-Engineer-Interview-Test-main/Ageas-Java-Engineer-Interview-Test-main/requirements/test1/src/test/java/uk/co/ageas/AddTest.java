package uk.co.ageas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class AddTest {

    private Add add;

    @Before
    public void setUp() {
        add = new Add();
    }

    @Test
    public void testAdditionWithPositiveNumbers() {
        assertEquals(10, add.addition(4, 6));
    }

    @Test
    public void testAdditionWithNegativeNumbers() {
        assertEquals(-10, add.addition(-4, -6)); 
        assertEquals(2, add.addition(-4, 6));
        assertEquals(-2, add.addition(4, -6)); 
    }

    @Test
    public void testAdditionWithZero() {
        assertEquals(5, add.addition(5, 0));
        assertEquals(0, add.addition(0, 0));
        assertEquals(-5, add.addition(-5, 0));
    }

    @Test
    public void testAdditionWithLargeNumbers() {
        assertEquals(2000000, add.addition(1000000, 1000000)); 
    }

    @Test
    public void testAdditionWithLargeNegativeNumbers() {
        assertEquals(-2000000, add.addition(-1000000, -1000000));
    }
}
