package uk.co.ageas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class DivideTest {

    private Divide divide;

    @Before
    public void setUp() {
        divide = new Divide(); 
    }

    @Test
    public void testDivisionWithPositiveNumbers() {
        assertEquals(5, divide.division(10, 2));
    }

    @Test
    public void testDivisionWithNegativeNumbers() {
        assertEquals(-5, divide.division(-10, 2)); 
    }

    @Test
    public void testDivisionWithZeroNumerator() {
        assertEquals(0, divide.division(0, 5)); 
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDivisionByZero() {
        divide.division(10, 0);
    }

    @Test
    public void testDivisionWithOneAsDenominator() {
        assertEquals(10, divide.division(10, 1)); 
    }

    @Test
    public void testDivisionWithNegativeDenominator() {
        assertEquals(-5, divide.division(10, -2)); 
    }

    @Test
    public void testDivisionWithLargeNumbers() {
        assertEquals(10000, divide.division(100000, 10)); 
    }

    @Test
    public void testDivisionWithBothNegativeNumbers() {
        assertEquals(5, divide.division(-10, -2)); 
    }
}
