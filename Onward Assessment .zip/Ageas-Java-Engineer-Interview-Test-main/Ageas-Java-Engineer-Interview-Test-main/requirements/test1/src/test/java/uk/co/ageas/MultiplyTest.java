package uk.co.ageas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class MultiplyTest {

    private Multiply multiply;

    @Before
    public void setUp() {
        multiply = new Multiply();
    }

    @Test
    public void testMultiplyWithPositiveNumbers() {
        assertEquals(20, multiply.multiplyNumbers(4, 5)); 
    }

    @Test
    public void testMultiplyWithNegativeNumbers() {
        assertEquals(-20, multiply.multiplyNumbers(-4, 5));
        assertEquals(20, multiply.multiplyNumbers(-4, -5));
    }

    @Test
    public void testMultiplyWithZero() {
        assertEquals(0, multiply.multiplyNumbers(0, 5));
        assertEquals(0, multiply.multiplyNumbers(4, 0));
        assertEquals(0, multiply.multiplyNumbers(0, 0));
    }

    @Test
    public void testMultiplyWithOne() {
        assertEquals(5, multiply.multiplyNumbers(1, 5));
        assertEquals(4, multiply.multiplyNumbers(4, 1));
    }

    @Test
    public void testMultiplyWithLargeNumbers() {
        assertEquals(1000000, multiply.multiplyNumbers(1000, 1000));
    }

    @Test
    public void testMultiplyWithLargeNegativeNumbers() {
        assertEquals(-1000000, multiply.multiplyNumbers(-1000, 1000)); 
    }
}
