package uk.co.ageas;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class TaskManagerTest {

	private TaskManager taskManager;

	@Before
	public void setUp() {
		taskManager = new TaskManager();
	}
	
	@Test
	public void testInitialTaskListSize() {
	    TaskManager taskManager = new TaskManager();
	    assertEquals(0, taskManager.retrieveTask().size());
	}
	
	@Test
	public void AddToTaskNotEmpty() {
		assertEquals(false, taskManager.addToTask().isEmpty());
	}

	@Test
	public void AddToTaskCheckSize() {
		assertEquals(6, taskManager.addToTask().size());
	}
	
	@Test
	public void AddToTaskMultipleTimesCheckSize() {
		taskManager.addToTask();
		taskManager.addToTask();
		assertEquals(12, taskManager.retrieveTask().size());
	}

	@Test
	public void checkSizeafterRemoval() {
		taskManager.addToTask();
		taskManager.markCompleted("Add test cases");
		assertEquals(5, taskManager.retrieveTask().size());
	}

	@Test
	public void retrieveTask() {
		taskManager.addToTask();
		assertEquals(6,taskManager.retrieveTask().size());
	}

	@Test
	public void testEmptyTaskList() {
	    TaskManager taskManager = new TaskManager();
	    taskManager.markCompleted("Non existent task");
	    assertEquals(0, taskManager.retrieveTask().size()); 
	}
	
	@Test
	public void testRemovingAllTasks() {
	    taskManager.addToTask();
	    taskManager.markCompleted("Add test cases");
	    taskManager.markCompleted("Run the test cases");
	    taskManager.markCompleted("Make sure it is failing");
	    taskManager.markCompleted("Write the code");
	    taskManager.markCompleted("Test all are passing");
	    taskManager.markCompleted("Refactor if any are failing");
	    
	    assertEquals(0, taskManager.retrieveTask().size());
	}
}
