package uk.co.ageas;

public class Substract {
	
	public int sub(int a, int b)
	{
		return a-b;
	}
}
