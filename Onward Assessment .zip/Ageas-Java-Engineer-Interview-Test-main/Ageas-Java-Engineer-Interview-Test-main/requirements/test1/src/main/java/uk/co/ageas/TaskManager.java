package uk.co.ageas;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

class TaskManager {
	private List<String> taskList = new LinkedList<String>();

	public List<String> addToTask() {
		taskList.add("Add test cases");
		taskList.add("Run the test cases");
		taskList.add("Make sure it is failing");
		taskList.add("Write the code");
		taskList.add("Test all are passing");
		taskList.add("Refactor if any are failing");
		return taskList;
	}

	public List<String> markCompleted(String taskDescription) {
		if (taskList.contains(taskDescription)) {
			taskList.remove(taskDescription); // Remove the specific task by description
		}
		return taskList;
	}

	public List<String> retrieveTask() {
		return taskList;
	}
}
