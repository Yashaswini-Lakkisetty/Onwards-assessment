package uk.co.ageas;

public class Multiply {

	public int multiplyNumbers(int a, int b) {
		
		return a*b;
	}
}
