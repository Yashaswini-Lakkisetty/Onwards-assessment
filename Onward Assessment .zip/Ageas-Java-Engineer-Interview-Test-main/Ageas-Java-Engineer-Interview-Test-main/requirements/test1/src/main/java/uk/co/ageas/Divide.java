package uk.co.ageas;

public class Divide {

	public int division(int a, int b) {
		
		if (b == 0) {
            throw new IllegalArgumentException("Divisor cannot be zero.");
        }

		return a/b;
	}
}
