package uk.co.ageas;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TaskManagerDynamic {
    private List<Task> tasks;

    public TaskManagerDynamic() {
        this.tasks = new ArrayList<>();
    }

    public void addTask(String description) {
        tasks.add(new Task(description));
    }

    public boolean markTaskAsCompleted(String description) {
        for (Task task : tasks) {
            if (task.getDescription().equalsIgnoreCase(description) && !task.isCompleted()) {
                task.markAsCompleted();
                return true;
            }
        }
        return false;
    }

    public List<Task> retrievePendingTasks() {
        return tasks.stream()
                    .filter(task -> !task.isCompleted())
                    .collect(Collectors.toList());
    }

    public List<Task> getAllTasks() {
        return tasks;
    }
}

