package uk.co.ageas;

public class Add {
	
	public int addition(int a, int b)
	{
		return a+b;
	}

}
